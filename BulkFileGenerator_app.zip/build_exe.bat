@echo off
REM ------------------------------------------------------------------
REM  Builds BulkFileGenerator.exe (Windows). Run this from the folder
REM  that contains BulkFileGenerator.py, bulk_engine.py and ui.html.
REM  Needs Python 3.9+ installed and on PATH.
REM ------------------------------------------------------------------
cd /d "%~dp0"

echo Installing build requirements...
python -m pip install --upgrade -r requirements.txt pyinstaller || goto :fail

echo Building the .exe...
python -m PyInstaller --noconfirm --clean --onefile ^
  --name BulkFileGenerator ^
  --add-data "ui.html;." ^
  BulkFileGenerator.py || goto :fail

echo.
echo Done! Your app is at:  %~dp0dist\BulkFileGenerator.exe
echo Copy it anywhere. config.json, Tracker\ and Output\ are created next to it on first run.
pause
exit /b 0

:fail
echo.
echo Build failed - see the messages above.
pause
exit /b 1
